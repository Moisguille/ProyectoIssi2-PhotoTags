"use strict";

import { photoRenderer } from "/js/renderers/photos.js";
import { photosAPI_auto } from "/js/api/_photos.js";
import { commentsAPI_auto } from "./api/_comments.js";
import { messageRenderer } from "/js/renderers/messages.js";

let urlParams = new URLSearchParams(window.location.search);
let photoId = urlParams.get("photoId");

async function loadPhotoDetails() {
    let photoContainer = document.querySelector("#photo-details-column");
    try {
        let photo = await photosAPI_auto.getById(photoId);
        let photoDetails = photoRenderer.asDetails(photo);
        photoContainer.appendChild(photoDetails);
    } catch (err) {
        messageRenderer.showErrorMessage("Error loading photo", err);
    }
}

async function handleDelete(event) {
    let answer = confirm("Do you really want to delete this photo?");
    
    if (answer) {
        try {
            await photosAPI_auto.delete(photoId);
            window.location = "/index.html";
        } catch (err) {
            messageRenderer.showErrorMessage(err.response.data.message);
        }
    }
}

function handleEdit(event) {
    window.location.href = "edit_photo.html?photoId=" + photoId;
}


// Función para traer y renderizar los comentarios asociados al photoId
async function fetchAndRenderComment(photoId) {
    try {
        // Llama al método en commentsAPI_auto para obtener los comentarios
        const response = await commentsAPI_auto.getCommentByPhotoId(photoId);
        const comments = response.data; // Array de comentarios
        console.log(comments); // Verifica que contiene los comentarios esperados

        // Selecciona el contenedor del comentario por su id
        const commentsContainer = document.getElementById("comment-container");
        console.log(commentsContainer); // Verifica que el contenedor existe
        commentsContainer.innerHTML = ""; // Limpia el contenido previo

        // Iterar sobre los comentarios y renderizarlos
        for (let i = 0; i < comments.length ; i++) {
            const comment = comments[i]; // Comentario actual
            const commentElement = document.createElement("div");
            commentElement.classList.add("comment");
            commentElement.innerHTML = `
                <p><strong>${comment.author}</strong> (${new Date(comment.date).toLocaleDateString()}):</p>
                <p>${comment.text}</p>
            `;
            commentsContainer.appendChild(commentElement); // Añadir cada comentario al contenedor
        }
    } catch (err) {
        console.error("Error fetching comments:", err);
        messageRenderer.showErrorMessage("Error loading the comments.");
    }
}

/*
 FUncion que debe de estar en _comments.js   :  
 
 * Gets all comments from 'comments' by the associated photoId 


getCommentByPhotoId: async function(photoId) {
    let response = await axios.get(`${BASE_URL}/comments?photoId=${photoId}`, requestOptions);
    return response.data; // Devuelve un array de comentarios
},
*/


async function main() {
    if (photoId === null) {
        messageRenderer.showErrorMessage("Please, provide a photoId");
        return;
    }
    loadPhotoDetails();

    let deleteBtn = document.getElementById("button-delete");
    deleteBtn.onclick = handleDelete;

    let editBtn = document.getElementById("button-edit");
    editBtn.onclick = handleEdit;

     // Llama a la función para cargar y renderizar el comentario relacionado al photoId
     await fetchAndRenderComment(photoId);

}

document.addEventListener("DOMContentLoaded", main);

