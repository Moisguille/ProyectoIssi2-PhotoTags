# Proyecto de examen
Este proyecto se usará como punto de partida en el examen de laboratorio de IISSI-2.