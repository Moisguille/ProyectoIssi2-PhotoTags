"use strict";

import { artistRenderer } from "./renderers/artistRenderer.js";

// Main function that will run when the page is ready
async function main() {
    let bodyDiv = document.getElementById("body");

    bodyDiv.innerHTML += await artistRenderer.asCardGallery();
}

document.addEventListener("DOMContentLoaded", main);

