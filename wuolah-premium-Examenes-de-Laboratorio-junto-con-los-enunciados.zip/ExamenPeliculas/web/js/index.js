"use strict";


import {moviesRenderer} from "/js/renderers/movie.js";

async function main() {
    let bodyDiv = document.getElementById("body");

    bodyDiv.innerHTML += await moviesRenderer.asCardGallery();
}





document.addEventListener("DOMContentLoaded", main);