//renderizador de galeria de peliculas

"use strict";

import { usersAPI_auto } from "../api/_users.js";
import { moviesAPI_auto} from "../api/_movies.js";


const galleryRenderer = {
    
    asCardGallery: async function () { 
        let movies = await moviesAPI_auto.getAll(); 

        let html = '';
        
        for(let movie of movies){ 

            let user = await usersAPI_auto.getById(movie.userId);
            html += this.asCard(movie , user);
        }

        return html;

    }
    

}

export { galleryRenderer };
