"use strict";

import { sessionManager } from "/js/utils/session.js";

//validamos las restricciones del problema
const movieValidator = {
    validateRegister: function (formData) {
        let errors = [];
        let director = formData.get("director");
        let numero = formData.get("numero");
       

        if (numero < 30 || numero > 200) {
            errors.push("El numero de pag debe estar entre 0 y 5000");
        }
        if (director.length < 3 || director.length % 5 != 0) {
            errors.push("El autor debe ser minimo de 3 letras y multiplo de 5");
        }
        if(!(sessionManager.isLogged())) {
            errors.push("El usuario tiene que estar conectado");
        }

        return errors;
    }
};
export { movieValidator };