"use strict";

import { messageRenderer } from "/js/renderers/messages.js";
import { moviesAPI_auto} from "./api/_movies.js"; //importar la base de datos
import{sessionManager} from "./utils/session.js";


// Main function that will run when the page is ready
let URLparams = new URLSearchParams(window.location.search);
let movieId = URLparams.get("movieId"); //aqui cambiar el "bookId" por el id que te de en la base de datos en tables
                                      //eso se mira en visual



function main() {
    //book-form es el id que le he puesto al formulario
    document.getElementById("form-movie-upload").onsubmit = sendForm;
    //esto es que cuando detecte el book-form y le das a submit se envie el formulario (que es la formula de abajo)
    if(movieId){
        
        document.getElementById("title").innerHTML = "Edit Movie";
        document.getElementById("btn").innerHTML = "Update";
        loadForm(); //esto es para cargar el formulario
    }
    }



    async function sendForm(event){
        let form = event.target;
        event.preventDefault();
    
        
        
    
        try{
            let formData = new FormData(form);

            formData.append("userId", sessionManager.getLoggedId());
    
            
            if (formData.get("director").length < 3 && formData.get("director").length % 5 != 0) {
                messageRenderer.showErrorMessage("El autor debe ser minimo de 3 letras y multiplo de 5");
                return;
            }
    
            if(formData.get("durationMinutes") < 20 || formData.get("durationMinutes") > 200){
                messageRenderer.showErrorMessage("La duracion debe ser mayor de 20 e inferior de 200 minutos");
                return;
            }
    
    
            if (!sessionManager.isLogged()) {
                messageRenderer.showErrorMessage("No puedes crear una pelicula si no estás conectado");
                return;
            }
    
            
            if(movieId){
                await moviesAPI_auto.update(formData, movieId);
            }
            else{
                await moviesAPI_auto.create(formData);
            }
    
            window.location.href = "/index.html";
    
        }catch(err){
            messageRenderer.showErrorMessage(err);
    
        }
    
    }

    async function loadForm(){
        let currentMovie = await moviesAPI_auto.getById(movieId); //aqui cargas la movie en funcion de la id
    
        //Lo que hay entre parentesis es el id de los input en el create_movie.html
        let inputDirector = document.getElementById("input_director"); 
        let inputTitle = document.getElementById("input_title");
        let inputDate = document.getElementById("input_date");
        let inputUrl = document.getElementById("input_url");
        let inputNumber = document.getElementById("input_number");
    
    
    
        try{
            //tiene que coincidir los nombres que salen de currentMovie con los de heidiSQL
            inputDirector.value = currentMovie.director;
            inputTitle.value = currentMovie.title;
            inputDate.value = currentMovie.releaseDate;
            inputUrl.value = currentMovie.imageUrl;
            inputNumber.value = currentMovie.durationMinutes;    
            
    
        }catch(error){
            messageRenderer.showErrorMessage(error);
        }
    }

    

    //Recuerde que los nombres de los atributos de los usuarios se deben corresponder con
    //los valores de los atributos “name” de los <input> del formulario.





document.addEventListener("DOMContentLoaded", main);