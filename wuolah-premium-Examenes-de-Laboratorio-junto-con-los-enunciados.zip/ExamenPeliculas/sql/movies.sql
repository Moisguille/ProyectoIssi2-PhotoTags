DROP TABLE IF EXISTS Movies;

CREATE TABLE Movies (
    movieId INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    userId INT NOT NULL,
    title VARCHAR(256) NOT NULL,
    director VARCHAR(256) NOT NULL,
    imageUrl VARCHAR(512) NOT NULL,
    releaseDate DATE NOT NULL,
    durationMinutes INT NOT NULL,
    FOREIGN KEY (userId) REFERENCES Users(userId)
);

CREATE OR REPLACE VIEW MoviesWithUsers AS 
    SELECT Movies.*, Users.username, Users.fullName, Users.avatarUrl, Users.city, Users.age
    FROM Movies
    JOIN Users ON Movies.userId = Users.userId;

INSERT INTO Movies (userId, title, director, releaseDate, durationMinutes, imageUrl)
VALUES
    (1, 'Clue', 'Jonathan Lynn', '1985-12-13', 97, 'https://upload.wikimedia.org/wikipedia/en/1/18/Clue_Poster.jpg'),
    (1, 'Murder on the Orient Express', 'Sidnet Lumet', '1974-11-21', 128, 'https://upload.wikimedia.org/wikipedia/en/6/61/Murder_on_the_Orient_Express_-_UK_poster.png'),
    (2, 'Pulp Fiction', 'Quentin Tarantino', '1994-10-14', 154, 'https://upload.wikimedia.org/wikipedia/en/3/3b/Pulp_Fiction_%281994%29_poster.jpg'),
    (2, 'Borat', 'Larry Charles', '2006-08-04', 84, 'https://upload.wikimedia.org/wikipedia/en/3/39/Borat_ver2.jpg'),
    (3, 'Interstellar', 'Christopher Nolan', '2014-11-05', 169, 'https://upload.wikimedia.org/wikipedia/en/b/bc/Interstellar_film_poster.jpg'),
    (3, 'Baby Driver', 'Edgar Wright', '2017-03-11', 113, 'https://upload.wikimedia.org/wikipedia/en/8/8e/Baby_Driver_poster.jpg');
    