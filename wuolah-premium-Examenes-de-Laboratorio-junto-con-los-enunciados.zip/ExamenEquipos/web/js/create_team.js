"use strict";

import { teamsAPI_auto } from "./api/_teams.js";
import { messageRenderer } from "./renderers/messages.js";

//URLSearch para analizar los parametros de la url
//teamId obtiene el valor del parametro "teamId"
let URLparams = new URLSearchParams(window.location.search);
let teamId = URLparams.get("teamId");

function main() {
    //asigna sendForm para manejar el evento de envio del formulario
    document.getElementById("team-form").onsubmit = sendForm;

    //si teamId esta presente -> cambiamos el titulo y el boton y llama a loadForm
    if(teamId){
        document.getElementById("title").innerHTML = "Edit team";
        document.getElementById("btn").innerHTML = "Update";
        loadForm();
    }
}

//enviar el formulario
async function sendForm(event){
    let form = event.target;
    event.preventDefault();

    try{
        let formData = new FormData(form);

        //restriccion de un parametro
        if(formData.get("president").length%5 !=0){
            messageRenderer.showErrorMessage("La longitud de president debe ser módulo 5");
            return;
        }

        //dependiendo de si esta id, actualiza o crea 
        if(teamId){
            await teamsAPI_auto.update(formData, teamId);
        }
        else{
            await teamsAPI_auto.create(formData);

        }

        //redirige una vez completado el envio
        window.location.href = "/teams.html";

    //muestra los errores
    }catch(err){
        messageRenderer.showErrorMessage(err);

    }

}

//carga el formulario
async function loadForm(){

    //obtiene los datos del team por Id
    let currentTeam = await teamsAPI_auto.getById(teamId);

    //name, president, fieldCapacity, foundationDate, photoURL
    let inputName = document.getElementById("name-input");
    let inputPresident = document.getElementById("president-input");
    let inputCapacity = document.getElementById("fieldCapacity-input");
    let inputDate = document.getElementById("foundationDate-input");
    let inputURL = document.getElementById("photoURL-input");

    //rellene el formulario con los datos del equipo
    try{
        inputURL.value = currentTeam.photoURL;
        inputDate.value = currentTeam.foundationDate;
        inputCapacity.value = currentTeam.fieldCapacity;
        inputPresident.value = currentTeam.president;
        inputName.value = currentTeam.name;

    }catch(error){
        messageRenderer.showErrorMessage(error);
        
    }
}

document.addEventListener("DOMContentLoaded", main);