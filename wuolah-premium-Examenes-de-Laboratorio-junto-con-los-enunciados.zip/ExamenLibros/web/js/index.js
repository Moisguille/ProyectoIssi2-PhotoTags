"use strict";
import { messageRenderer } from "/js/renderers/messages.js";
import { booksAPI_auto } from "/js/api/_books.js";
import {galleryRenderer} from "/js/renderers/gallery.js";


async function main() {
    loadAllBooks();

   
    }


async function loadAllBooks() {
    let galleryContainer = document.querySelector("div.container");
    try {
        let books = await booksAPI_auto.getAll();
        let cardGallery = galleryRenderer.asCardGallery(books);
        galleryContainer.appendChild(cardGallery);

    } catch (err) {
        messageRenderer.showErrorMessage("Error while loading books",err);
    }
}



document.addEventListener("DOMContentLoaded", main);