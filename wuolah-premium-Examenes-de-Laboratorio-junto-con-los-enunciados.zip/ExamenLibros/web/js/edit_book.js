
"use strict";

import { messageRenderer } from "/js/renderers/messages.js";
import { booksAPI_auto } from "/js/api/_books.js";


let urlParams = new URLSearchParams(window.location.search);
let bookId = urlParams.get("bookId");


function main() {

    //asigna sendForm para manejar el evento de envio del formulario
    document.getElementById("form-book-upload").onsubmit = sendForm;

    //si bookId esta presente -> cambiamos el titulo y el boton y llama a loadForm
    if(bookId){
        document.getElementById("title").innerHTML = "Edit book";
        document.getElementById("boton").innerHTML = "Update";
        loadForm();
    }
}

//enviar el formulario
async function sendForm(event){
    let form = event.target;
    event.preventDefault();

    try{
        let formData = new FormData(form);

        //restricciones
        if(formData.get("author").length<3){
            messageRenderer.showErrorMessage("La longitud del autor debe ser mayor de 3");
            return;
        }

        if(formData.get("numero")<0 || formData.get("numero")>5000){
            messageRenderer.showErrorMessage("El numero de páginas tiene que estar entre 0 y 5000");
            return;
        }

        //book de si esta id, actualiza o crea 
        if(bookId){
            await booksAPI_auto.update(formData, bookId);
        }
        else{
            await booksAPI_auto.create(formData);

        }

        //redirige una vez completado el envio
        window.location.href = "/index.html";

    //muestra los errores
    }catch(err){
        messageRenderer.showErrorMessage(err);

    }

}

    
//carga el formulario
async function loadForm(){

    //obtiene los datos del book por Id
    let currentBook = await booksAPI_auto.getById(bookId);

    //nombre, autor,  url, num pag, fecha
    let autorInput = document.getElementById("input-author");
    let urlInput = document.getElementById("input-url");
    let titleInput = document.getElementById("input-title");
    let numberInput = document.getElementById("input-number");
    let dateInput = document.getElementById("input-date");

    //rellene el formulario con los datos del equipo
    //los nombres tienen que coincidir con los que hay en HeidiSQL
    try{
        autorInput.value = currentBook.author;
        urlInput.value = currentBook.imageUrl;
        titleInput.value = currentBook.title;
        numberInput.value = currentBook.numPages;
        dateInput.value = currentBook.releaseDate;

    }catch(error){
        messageRenderer.showErrorMessage(error);
        
    }
}


document.addEventListener("DOMContentLoaded", main);