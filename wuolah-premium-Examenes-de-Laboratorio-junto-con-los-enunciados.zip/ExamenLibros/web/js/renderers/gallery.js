"use strict";
import { booksRenderer } from "/js/renderers/books.js";
import { parseHTML } from "/js/utils/parseHTML.js";


const galleryRenderer = {
    asCardGallery: function(books) {
        
        let galleryContainer = parseHTML('<div class="book-gallery"></div>');
        let row = parseHTML('<div class="row"></div>');
        galleryContainer.appendChild(row);

        let counter = 0;

        for (let book of books) {//recorremos todas las fotos
            let card = booksRenderer.asCard(book);
            row.appendChild(card);
            counter += 1;

            if (counter % 3 === 0) {//como nuestra galeria contiene 3 fotos por fila, cada 3 fotos añadimos una fila nueva
            row = parseHTML('<div class="row"></div>');
            galleryContainer.appendChild(row);
            }

        
    }
    return galleryContainer;
}

}

export { galleryRenderer };