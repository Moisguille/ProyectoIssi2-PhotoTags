
"use strict";
import { parseHTML } from "/js/utils/parseHTML.js";


//objeto photorenderer que contendrá funciones de renderizado de fotos y luego lo exportamos
//para que pueda ser importado en otros lugares del codigo


const booksRenderer = {

    //los atributos actuan como funciones
    //renderizador de fotos
    asCard : function(book) {
        
        let html = `
        <div class="col-md-4">
            <div class="card bg-dark text-light">
            <a href="edit_book.html?bookId=${book.bookId}">
                <img src="${book.imageUrl}" class="card-img-top">
            </a>
                    
                <div class="card-body">
                    
                    <h5 class="card-title text-center">${book.title}</h5>
                    <p class="card-text">${book.author}</p>
                    <p class="card-text">${book.releaseDate}</p>
                    <p class="card-text">${book.numPages}</p> 

                </div>
            </div>
        </div>`;

        let card = parseHTML(html);
        return card;
        }

    


};

export { booksRenderer };

