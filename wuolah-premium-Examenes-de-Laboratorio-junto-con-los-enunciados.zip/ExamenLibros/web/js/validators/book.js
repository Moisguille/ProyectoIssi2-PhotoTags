"use strict";

//como los renderizados pero para las validaciones de formulario
const bookValidator = {
    validateRegister: function (formData) {
        let errors = [];
        let autor = formData.get("author");
        let numero = formData.get("numero");
       

        if (numero < 0 || numero > 5000) {
            errors.push("El numero de pag debe estar entre 0 y 5000");
        }
        if (autor.length < 3) {
            errors.push("El autor debe ser minimo de 3 nombres");
        }

        return errors;
    }
};
export { bookValidator };