"use strict";

import { parseHTML } from "/js/utils/parseHTML.js"; // Crea elementos del DOM a partir de fuente html

const badgeRenderer = {
    showAsBadge: function (badge, photoId,userId) {
        let html = `<span class="badge caja bg-secondary" onclick='borrarTag(${badge.tagId},${photoId},${userId})'><span class="badge rounded-pill bg-light text-dark">${badge.photoTagId}</span> ${badge.name}</span>`;
        return html;
    },
    showAsBadgePill: function (badge) {
        let html = `<span class="badge rounded-pill bg-secondary">${badge.name}</span>`;
        return html;
    }
}

export { badgeRenderer };