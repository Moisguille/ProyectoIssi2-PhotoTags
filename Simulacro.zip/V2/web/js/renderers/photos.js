/*
	C.Arévalo, Mayo/2025
	photos.js.  Renderización de Fotos y photosTags (Solución de partida, en bruto)
*/
"use strict";
import { parseHTML } from "/js/utils/parseHTML.js"; // Crea elementos del DOM a partir de fuente html
import { badgeRenderer } from "/js/renderers/badges.js";
import { sessionManager } from "/js/utils/session.js";

const photoRenderer = {
	asCard: function (photo, photosTags) { // Renderiza un objeto photo como card y a continuación todos sus photoTags como texto en bruto
		let thisPhoto_photosTags = photosTags.filter(item => item.photoId == photo.photoId); // Extrae photoTags del objeto photo renderizado en cada card
		let tags = ``;
		for (let tag of thisPhoto_photosTags) {
			tags+= badgeRenderer.showAsBadge(tag,photo.photoId,photo.userId) + ' ';
		}
		
		if(sessionManager.isLogged()) tags+= `<a href="addTag.html?userId=${photo.userId}&photoId=${photo.photoId}"><span class="badge caja bg-secondary">Add Tag</span></a>`;
		
		let html = `<div class="card col-sm-3 p-1 mb-1 text-center">
					<h5>#${photo.photoId} ${photo.title} ${photo.visibility}</h5>
					<img src="${photo.url}" class="img-fluid w-100">
				`;
		/* 	El alumno tiene que renderizar adecuadamente conforme a los requisitos de los apartados (1, 2 y 3)
				  A continuación se muestra el array JSON de cada photo como texto en bruto (método stringify)
		*/
		html += `<div class="fw-light photosTags mt-1">`+tags+`</div>`;
		return parseHTML(html);
		
	},
};
export { photoRenderer };