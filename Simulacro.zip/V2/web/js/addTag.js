"use strict";

import { photoswithtagsAPI_auto } from "/js/api/_photoswithtags.js";
import { tagsAPI_auto } from "/js/api/_tags.js";
import { parseHTML } from "/js/utils/parseHTML.js"; // Crea elementos del DOM a partir de fuente html
import { photostagsAPI_auto } from "/js/api/_photostags.js";
import { messageRenderer } from '/js/renderers/messages.js'; // Renderizador de mensajes

let urlParams = new URLSearchParams(window.location.search);
let photoId = urlParams.get("photoId");
let userId = urlParams.get("userId");

async function main() {
    let options = document.getElementById("tagSelector");
    let photosTags = await photoswithtagsAPI_auto.getAll();
    let thisPhoto_photosTags = photosTags.filter(item => item.photoId == photoId);
    let allTags = await tagsAPI_auto.getAll();
    let usedTags = [];
    for (let tag of thisPhoto_photosTags) {
        let t = await tagsAPI_auto.getById(tag.tagId);
        usedTags.push(t.tagId);
    }
    let notUsed = allTags.filter(e => !(usedTags.includes(e.tagId)));
    if (notUsed.length === 0) {
        window.alert("No quedan tags disponibles para añadir a la imagen.");
        window.location = "index.html";
    }
    for (let tag of notUsed) {
        let html = `<option value="${tag.tagId}">${tag.name}</option>`
        options.appendChild(parseHTML(html));
    }



}

async function addTag() {
    try {
        let options = document.getElementById("tagSelector");
        let formData = new FormData();
        formData.append("photoId", photoId);
        formData.append("tagId", options.value);
        let rep = await photostagsAPI_auto.create(formData);
        window.location = "index.html";
    } catch(err) {
        messageRenderer.showErrorMessage(JSON.stringify(err.response.data));
    }

}
window.addTag = addTag;
document.addEventListener("DOMContentLoaded", main);