/*
	C.Arévalo
	index.js.  Control de vista index.html, Mayo/2025
*/
"use strict";						// Nivel elevado de control de errores
import { photoRenderer } from '/js/renderers/photos.js'; // Renderizador de fotos
import { messageRenderer } from '/js/renderers/messages.js'; // Renderizador de mensajes
import { photosAPI_auto } from './api/_photos.js'; // Controlador API de photos
import { photoswithtagsAPI_auto } from './api/_photoswithtags.js'; // Controlador API de la vista photosWithTags
import { sessionManager } from "/js/utils/session.js";
import { photostagsAPI_auto } from "/js/api/_photostags.js";

async function main() {//Punto de entrada principal, haciéndolo asíncrono para poder llamar AJAX
	if (sessionManager.isLogged()) {
		try { // Acceso con éxito a las fotos
			let titulo = document.getElementById("title");
			let user = sessionManager.getLoggedUser();
			if (user.firstName === "root") {
				titulo.textContent = `“Tags. Admin Management as 'root'”`;
				let photos = await photosAPI_auto.getAll(); // Todos los pbjetos photo
				let photosTags = await photoswithtagsAPI_auto.getAll(); // photos con photoTags, incluyendo además datos de cada tag
				let photoContainer = document.querySelector("#divGallery"); /* Contenedor para photos */
				for (let photo of photos) {
					photoContainer.appendChild(photoRenderer.asCard(photo, photosTags)); // Añade card con photo y sus photoTags
				}
			} else {
				titulo.textContent = "Tags. My Tags’ Management";
				let photosT = await photosAPI_auto.getAll(); // Todos los pbjetos photo, tengan o no photoTags
				let photos = photosT.filter(p => p.userId === user.userId && p.visibility === "Private");
				let photosTags = await photoswithtagsAPI_auto.getAll(); // photos con photoTags, incluyendo además datos de cada tag
				let photoContainer = document.querySelector("#divGallery"); /* Contenedor para photos */
				for (let photo of photos) {
					photoContainer.appendChild(photoRenderer.asCard(photo, photosTags)); // Añade card con photo y sus photoTags
				}
			}

		}
		catch (err) { // Renderiza error
			console.log(err);
			messageRenderer.showErrorMessage(JSON.stringify(err.response.data));
		};
	} else {
		try { // Acceso con éxito a las fotos
			let photos = await photosAPI_auto.getAll(); // Todos los pbjetos photo, tengan o no photoTags
			let photosTags = await photoswithtagsAPI_auto.getAll(); // photos con photoTags, incluyendo además datos de cada tag
			let photoContainer = document.querySelector("#divGallery"); /* Contenedor para photos */
			for (let photo of photos) {
				photoContainer.appendChild(photoRenderer.asCard(photo, photosTags)); // Añade card con photo y sus photoTags
			}
		}
		catch (err) { // Renderiza error
			console.log(err);
			messageRenderer.showErrorMessage(JSON.stringify(err.response.data));
		};
	}

};



async function borrarTag(tagId, photoId, userId) {
	if (sessionManager.isLogged()) {
		let user = sessionManager.getLoggedUser();
		if (user.firstName === "root" || user.userId === userId) {
			let conf = window.confirm("¿Seguro que quieres eliminar la tag?");
			if (conf) {
				try {
					let tags = await photostagsAPI_auto.getAll();
					let tag = tags.filter(e => e.photoId === photoId && e.tagId === tagId)[0];
					let del = await photostagsAPI_auto.delete(tag.photoTagId);
					window.location = "index.html";
				} catch (err) {
					console.log(err);
					messageRenderer.showErrorMessage(JSON.stringify(err.response.data));
				}

			}
		} else {
			window.alert("No tiene permisos para eliminar etiquetas de fotos que no le pertenezcan.");
		}


	}

};

window.borrarTag = borrarTag;
document.addEventListener("DOMContentLoaded", main); // Manejador de eventos para documento cargado