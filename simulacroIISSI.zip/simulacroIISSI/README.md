# silence-template-v2-blank
This is an empty Silence project.
