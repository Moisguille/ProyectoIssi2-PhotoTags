/*
	C.Arévalo
	index.js.  Control de vista index.html, Mayo/2025
*/
"use strict";						// Nivel elevado de control de errores
import { photoRenderer } from '/js/renderers/photos.js'; // Renderizador de fotos
import { messageRenderer } from '/js/renderers/messages.js'; // Renderizador de mensajes
import { photosAPI_auto } from './api/_photos.js'; // Controlador API de photos
import { photoswithtagsAPI_auto } from './api/_photoswithtags.js'; // Controlador API de la vista photosWithTags
import { sessionManager } from './utils/session.js';
import { photostagsAPI_auto } from './api/_photostags.js';
import { tagsAPI_auto } from "./api/_tags.js";

async function main() {//Punto de entrada principal, haciéndolo asíncrono para poder llamar AJAX
	try { // Acceso con éxito a las fotos
		let photos = await photosAPI_auto.getAll(); // Todos los pbjetos photo, tengan o no photoTags
		let photosTags = await photoswithtagsAPI_auto.getAll(); // photos con photoTags, incluyendo además datos de cada tag
		let tags = await tagsAPI_auto.getAll();
		let photoContainer = document.querySelector("#divGallery"); /* Contenedor para photos */
		let titulo = document.getElementById("pageTitle");

		for (let photo of photos) {
			if (sessionManager.isLogged()) {
				if (sessionManager.getLoggedUser().firstName === `root`) {
					photoContainer.appendChild(photoRenderer.asCardAdd(photo, photosTags, tags)); // Añade card con photo y sus photoTags
					titulo.innerText = `Tags. Admin Management as 'root'`;
				}
				else if (photo.visibility === `Private`) {
					photoContainer.appendChild(photoRenderer.asCardAdd(photo, photosTags, tags)); // Añade card con photo y sus photoTags
					titulo.innerText = `Tags. My Tags’ Management`;

				}
				eliminarTags();
				añadirTag();
			}
			else {
				if (photo.visibility === `Public`) {
					photoContainer.appendChild(photoRenderer.asCard(photo, photosTags)); // Añade card con photo y sus photoTags
					titulo.innerText = `Tags. Public View`;

				}
			}
		}



	}
	catch (err) { // Renderiza error
		console.log(err);
		messageRenderer.showErrorMessage(JSON.stringify(err.response.data));
	};
};

async function eliminarTags() {
	for (let boton of document.getElementsByName("eliminar-tag")) {
		boton.onclick = handleEliminar;
	}
}

async function añadirTag() {
	let forms = document.querySelectorAll(".anadirTag");
for(let form of forms){
	form.onsubmit = handleAñadir;
}
}



async function handleEliminar(event) {
	event.preventDefault();
	let boton = event.currentTarget;
	boton.disabled = true;
	try {
		await photostagsAPI_auto.delete(boton.value);
		window.location.href = "index.html";
	} catch (err) {
		messageRenderer.showErrorMessage("Error while deleting", err);
	}
}

async function handleAñadir(event) {
	event.preventDefault();
	let form = event.target;
	let formData = new FormData(form);
	try {
		let a = await photostagsAPI_auto.create(formData);
		            let newId = a.lastId;

		window.location.href = "index.html";
	} catch (err) {
		messageRenderer.showErrorMessage("Error while creating", err);
	}
}

document.addEventListener("DOMContentLoaded", main); // Manejador de eventos para documento cargado