/*
	IISSI2
	index.js.  Controlador de index.html
	Mayo/2025
*/
"use strict";						// Nivel elevado de control de errores

import { galleryRenderer } from '/js/renderers/gallery.js';
import { messageRenderer } from './renderers/messages.js';   // Renderizadores necesarios 
import { photosAPI_auto } from './api/_photos.js';
import { photostagsAPI_auto } from '/js/api/_photostags.js'
import { tagsAPI_auto } from '/js/api/_tags.js' 	// Controladores de API necesarios para accesos Ajax a la BD
import { sessionManager } from "/js/utils/session.js";  // Gestión del Login/Logout y de la Sesión y Local Storage en Cliente

// Manejadores de eventos y/o listeners para satisfacer requisitos
// Accesos a la BD mediante controladores API Rest
// Presentación mediante módulos de renderización
// Captura de errores y renderización en contenedor de errores






const pageTitle = document.getElementById("pageTitle");
async function main() {
	try {
		let photosTags = await photostagsAPI_auto.getAll();
		let tags = await tagsAPI_auto.getAll();
		let galleryPhotos = await photosAPI_auto.getAll();
		let container = document.querySelector("#divGallery");
		container.appendChild(galleryRenderer.asCardGallery
			(galleryPhotos, photosTags, tags));
	} catch (err) {
		messageRenderer.showErrorMessage(err);
	}
	changeForUser();
}
async function changeForUser() {
	const badges = document.getElementsByClassName("badge");
	if (sessionManager.isLogged()) {
		pageTitle.innerHTML = `My Tags’ Management`;
		for (let badge of badges) {
			badge.disabled = false;
			badge.innerHTML += ` <i class="fa fa-close">`;
			badge.onclick = handleDelete;
		}
	} else {
		for (let badge of badges) {
			badge.className += " disabledLink";
		}
	}
}
async function handleDelete(event) {
	event.preventDefault();
	if (confirm("Do you really want to delete this tag?")) {
		try {
			const urlParams = new
				URLSearchParams(event.currentTarget.search);
			const photoTagId = urlParams.get("photoTagId");
			await photostagsAPI_auto.delete(photoTagId); // Borrar 
			window.location.href = "index.html"; // Redirección 
		} catch (err) {
			messageRenderer.showErrorMessage(err);
		}
	}
}
document.addEventListener("DOMContentLoaded", main);