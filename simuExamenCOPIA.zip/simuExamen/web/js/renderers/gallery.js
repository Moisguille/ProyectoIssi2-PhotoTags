"use strict";
import { parseHTML } from "/js/utils/parseHTML.js"; // Función para crear elementos del DOM
import { photoRenderer } from "/js/renderers/photos.js"; // Renderizador de una photo
import { sessionManager } from "/js/utils/session.js";
const galleryRenderer = {
    asCardGallery: function (photos, photosTags, tags) {
        let galleryContainer = parseHTML('<div class="photo-gallery row p - 2 bg - light"> </div>'); // Div a incrustar en contenedor de la galería 
 if (!sessionManager.isLogged()) {
            for (let photo of photos) { // Creación del Grid 
                if (photo.visibility === "Public") {

                    galleryContainer.appendChild(photoRenderer.asCard(photo, photosTags, tags));
                    // Añade cards al contenedor 
                }
            }
        } else if (sessionManager.getLoggedUser().username === "root") {
            for (let photo of photos) {

                galleryContainer.appendChild(photoRenderer.asCard(photo, photosTags, tags));
            }
        } else {
            for (let photo of photos) { // Creación del Grid 
                if (sessionManager.getLoggedId() === photo.userId) {

                    galleryContainer.appendChild(photoRenderer.asCard(photo, photosTags, tags));
                    // Añade cards al contenedor 
                }
            }
        }
        return galleryContainer; // Devuelve el div con todas las fotos. Se 
        //incrustará en el conteenedor de la galería
    }
}
export { galleryRenderer };