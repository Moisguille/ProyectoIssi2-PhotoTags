"use strict";
import { parseHTML } from "/js/utils/parseHTML.js"; // Función para crear elementos del DOM
const photoRenderer = {
    //Devuelve Card para la galería 
    asCard: function (photo, photosTags, tags) { // El parámetro es un objeto 
        photo
        let htmlTags = ``;
        for (let phototag of photosTags) { // Creación del Grid 
            if (phototag.photoId === photo.photoId) {
                for (let tag of tags) {
                    if (tag.tagId === phototag.tagId) {
                        htmlTags += `<a class="badge bg-secondary m-1 tag" 
                        href="index.html?photoTagId=${phototag.photoTagId}">${tag.name}</a>`;
                    }
                }

            }
        }
        let html = `<div class="col-sm-4 card mb-1 p-1"> 
 <div class=""> 
 <img src="${photo.url}" class="w-100"> 
 </div> 
 <div class="card-body text-center m-0 p-0"> 
 <h5 class="card-title m-0">#${photo.photoId}
${photo.title}</h5> 
 <div class="card-text m-0 
cardList">${htmlTags}</div> 
 </div> 
 
 </div>`;
        let card = parseHTML(html);
        return card;
    },

};
export { photoRenderer };